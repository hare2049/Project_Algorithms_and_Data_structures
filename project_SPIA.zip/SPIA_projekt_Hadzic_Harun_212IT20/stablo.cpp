#ifndef STABLO_CPP
#define STABLO_CPP
#include "stablo.h"
#include <iostream>
#include <vector>
using namespace std;

template <typename Tip>
Stablo<Tip>::Stablo() {
  korijen = nullptr;
  broj_elemenata = 0;
}

template <typename Tip>
pair<typename Stablo<Tip>::Cvor*,bool> Stablo<Tip>::Insert(Tip element) {

  if(korijen == nullptr) {
    korijen = new Cvor(element);
    broj_elemenata = 1;
    return {korijen, true};
  }

  Cvor *trenutni = korijen, *prethodni = nullptr;
  while(trenutni != nullptr) {
    if(element == trenutni->element)
        return {trenutni, false};
    prethodni = trenutni;
    if(element < trenutni->element)
        trenutni = trenutni->ld;
    else trenutni = trenutni->dd;
  }
  broj_elemenata++;
  Cvor *novi = new Cvor(element,prethodni);
  if(element < prethodni->element)
    prethodni->ld = novi;
  else prethodni->dd = novi;
  return {novi,true};
}

template <typename Tip>
typename Stablo<Tip>::Cvor* Stablo<Tip>::Find(Tip element) {
  Cvor* trenutni = korijen;
  while(trenutni != nullptr) {
    if(element == trenutni->element)
      return trenutni;
    if(element < trenutni->element)
      trenutni = trenutni->ld;
    else trenutni = trenutni->dd;
  }
  return nullptr;
}

template <typename Tip>
void Stablo<Tip>::InOrderRek(Cvor* cvor) {
  if(cvor==nullptr)
    return;
  InOrderRek(cvor->ld);
  cout<<cvor->element<<" ";
  InOrderRek(cvor->dd);
}

template <typename Tip>
void Stablo<Tip>::InOrder() {
  Cvor* trenutni = NadjiNajmanji(korijen);
  while(trenutni != nullptr) {
    cout<<trenutni->element<<" ";
    trenutni = NadjiSljedbenika(trenutni);
  }
}

template <typename Tip>
typename Stablo<Tip>::Cvor* Stablo<Tip>::NadjiNajmanji(Stablo<Tip>::Cvor *cvor) {
  if(cvor == nullptr)
    return nullptr;
  Cvor *trenutni = cvor;
  while(trenutni->ld != nullptr)
    trenutni = trenutni->ld;
  return trenutni;
}
//MOJAAAAAAAAAAAAAAAAAAAA
template <typename Tip>
typename Stablo<Tip>::Cvor* Stablo<Tip>::NadjiNajveci(Stablo<Tip>::Cvor *cvor) {
  if(cvor == nullptr)
    return nullptr;
  Cvor *trenutni = cvor;
  while(trenutni->dd != nullptr)
    trenutni = trenutni->dd;
  return trenutni;
}

template <typename Tip>
typename Stablo<Tip>::Cvor* Stablo<Tip>::NadjiSljedbenika(Stablo<Tip>::Cvor *cvor) {
  if(cvor->dd != nullptr)
    return NadjiNajmanji(cvor->dd);
  Cvor* trenutni = cvor;
  while(trenutni != korijen && trenutni == trenutni->rod->dd)
    trenutni = trenutni->rod;
  if(trenutni == korijen)
    return nullptr;
  else return trenutni->rod;
}

template <typename Tip>
int Stablo<Tip>::Erase(const Tip &element) {
  Cvor *za_brisanje = Find(element);
  if(za_brisanje != nullptr) {
    Erase(za_brisanje);
    return 1;
  }
  else return 0;
}

template <typename Tip>
void Stablo<Tip>::Erase(Cvor *za_brisanje) {

  if(za_brisanje->dd == nullptr) {  //ako nema desnog djeteta
    if(za_brisanje->ld == nullptr) { //ako nema ni lijevog
        if(za_brisanje->rod != nullptr) { //ako ima roditelja
            if(za_brisanje->rod->dd == za_brisanje)
                za_brisanje->rod->dd = nullptr;
            else za_brisanje->rod->ld = nullptr;  //ako nema roditelja, tada je korijen
        }
        else korijen = nullptr;
    }
    else {  //ako ima lijevo dijete
        if(za_brisanje->rod != nullptr) { //ako ima roditelja
            if(za_brisanje->rod->dd == za_brisanje)
                za_brisanje->rod->dd = za_brisanje->ld;
            else za_brisanje->rod->ld = za_brisanje->ld;  //ako nema roditelja, tada je korijen
            za_brisanje->ld->rod = za_brisanje->rod;
        }
        else {
            korijen = za_brisanje->ld;
            za_brisanje->ld->rod = nullptr;
        }
    }
  }
  else {
    Cvor* sljedbenik = NadjiSljedbenika(za_brisanje);
    if(sljedbenik->rod == za_brisanje) {
        sljedbenik->rod = za_brisanje->rod;
        if(za_brisanje->rod != nullptr) {
            if(za_brisanje->rod->dd == za_brisanje)
                za_brisanje->rod->dd = sljedbenik;
            else za_brisanje->rod->ld = sljedbenik;
        }
        else korijen = sljedbenik;
        if(za_brisanje->ld != nullptr)
            za_brisanje->ld->rod = sljedbenik;
        sljedbenik->ld = za_brisanje->ld;
    }
    else {
       sljedbenik->rod->ld = sljedbenik->dd;
       if(sljedbenik->dd != nullptr)
         sljedbenik->dd->rod = sljedbenik->rod;
       sljedbenik->dd = za_brisanje->dd;
       za_brisanje->dd->rod = sljedbenik;
       sljedbenik->ld = za_brisanje->ld;
       if(za_brisanje->ld != nullptr)
         za_brisanje->ld->rod = sljedbenik;
       sljedbenik->rod = za_brisanje->rod;
       if(za_brisanje->rod != nullptr) {
          if(za_brisanje->rod->ld == za_brisanje)
            za_brisanje->rod->ld = sljedbenik;
          else za_brisanje->rod->dd = sljedbenik;
       }
       else korijen = sljedbenik;
    }
  }

  delete za_brisanje;
  broj_elemenata--;

}

template <typename Tip>
typename Stablo<Tip>::Iterator Stablo<Tip>::Iterator::operator++(){
    if(this->pok->dd != nullptr){
        this->pok = this->pok->dd;
        this->IdiNaNajmanjiNaGrani();
        return this;
    }
    while(this->pok->rod != nullptr && this->pok == this->pok->rod->dd){
        this->pok = this->pok->rod;
        }
    if(this->pok->rod == nullptr){
        return this;
    }
    else{
        this->pok = this->pok->rod;
        return this;
    }
}

template <typename Tip>
typename Stablo<Tip>::Iterator Stablo<Tip>::Iterator::operator++(int){
    Iterator vrati(this);
    if(this->pok->dd != nullptr){
        this->pok = this->pok->dd;
        this->IdiNaNajmanjiNaGrani();
        return vrati;
    }
    while(this->pok->rod != nullptr && this->pok == this->pok->rod->dd){
        this->pok = this->pok->rod;
        }
    if(this->pok->rod == nullptr){
        return vrati;
    }
    else{
        this->pok = this->pok->rod;
        return vrati;
    }
}

template <typename Tip>
typename Stablo<Tip>::Iterator Stablo<Tip>::Iterator::IdiNaNajmanjiNaGrani() {
  if(this->pok == nullptr)
    return this;
  while(this->pok->ld != nullptr)
    this->pok = this->pok->ld;
  return this;
}

template <typename Tip>
typename Stablo<Tip>::Iterator Stablo<Tip>::Iterator::IdiNaNajveciNaGrani() {
  if(this->pok == nullptr)
    return this;
  while(this->pok->dd != nullptr)
    this->pok = this->pok->dd;
  return this;
}

template <typename Tip>
typename Stablo<Tip>::Reverse_Iterator Stablo<Tip>::Reverse_Iterator::operator++(){
    if(this->pok->ld != nullptr){
        this->pok = this->pok->ld;
        this->IdiNaNajveciNaGrani();
        return this;
    }
    while(this->pok->rod != nullptr && this->pok == this->pok->rod->ld){
        this->pok = this->pok->rod;
        }
    if(this->pok->rod == nullptr){
        return this;
    }
    else{
        this->pok = this->pok->rod;
        return this;
    }
}

template <typename Tip>
typename Stablo<Tip>::Reverse_Iterator Stablo<Tip>::Reverse_Iterator::operator++(int){
    Reverse_Iterator vrati(this);
    if(this->pok->ld != nullptr){
        this->pok = this->pok->ld;
        this->IdiNaNajveciNaGrani();
        return vrati;
    }
    while(this->pok->rod != nullptr && this->pok == this->pok->rod->ld){
        this->pok = this->pok->rod;
        }
    if(this->pok->rod == nullptr){
        return vrati;
    }
    else{
        this->pok = this->pok->rod;
        return vrati;
    }
}

template <typename Tip>
typename Stablo<Tip>::Reverse_Iterator Stablo<Tip>::Reverse_Iterator::IdiNaNajmanjiNaGrani() {
  if(this->pok == nullptr)
    return this;
  while(this->pok->ld != nullptr)
    this->pok = this->pok->ld;
  return this;
}

template <typename Tip>
typename Stablo<Tip>::Reverse_Iterator Stablo<Tip>::Reverse_Iterator::IdiNaNajveciNaGrani() {
  if(this->pok == nullptr)
    return this;
  while(this->pok->dd != nullptr)
    this->pok = this->pok->dd;
  return this;
}

template <typename Tip>
bool provjeriPodstablo(Stablo<Tip>& s1, Stablo<Tip>& s2){
    if(s1.korijen == nullptr || s2.korijen == nullptr)
        return false;
    vector<Tip> v1;
    typename Stablo<Tip>::Cvor* trenutni = s1.NadjiNajmanji(s1.korijen);
    while(trenutni != nullptr) {
        v1.push_back(trenutni->element);
        trenutni = s1.NadjiSljedbenika(trenutni);
    }

    trenutni = s2.NadjiNajmanji(s2.korijen);
    int indeks = 0;
    while(indeks != v1.size()-1) {
        if(v1[indeks] == trenutni->element){
            indeks++;
            continue;
        }
        if(v1[indeks] < trenutni->element){
            return false;
        }
        trenutni = s2.NadjiSljedbenika(trenutni);
    }
    return true;
};


template <typename Tip>
typename Stablo<Tip>::Cvor* Stablo<Tip>::ktiNajveci(typename Stablo<Tip>::Cvor* kr, int k, int& brojac) {
    if (kr == nullptr) return nullptr;
    typename Stablo<Tip>::Cvor* desni = ktiNajveci(kr->dd, k, brojac);
    if (desni != nullptr) return desni;
    brojac++;
    if (brojac == k) return kr;
    typename Stablo<Tip>::Cvor* lijevi = ktiNajveci(kr->ld, k, brojac);
    return lijevi;
}

template <typename Tip>
Tip Stablo<Tip>::operator [](int k){
    int brojac = 0;
    k++;
    typename Stablo<Tip>::Cvor* rezultat = ktiNajveci(korijen, k, brojac);

    return rezultat->element;
}


#endif // STABLO_CPP
