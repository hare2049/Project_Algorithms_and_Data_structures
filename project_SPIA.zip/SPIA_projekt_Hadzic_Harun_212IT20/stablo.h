#ifndef STABLO_H
#define STABLO_H
#include <utility>
#include <iostream>

using namespace std;

template <typename Tip>
class Stablo{
public:
    struct Cvor {
      Tip element;
      Cvor *ld, *dd, *rod;
      Cvor(Tip el, Cvor* rod = nullptr, Cvor* ld = nullptr, Cvor* dd = nullptr):
          element(el), rod(rod), ld(ld), dd(dd) {}
    };
protected:
    int broj_elemenata;
    Cvor* korijen;
    void InOrderRek(Cvor*);
    Cvor* NadjiNajmanji(Cvor*);
    Cvor* NadjiNajveci(Cvor*);
    Cvor* ktiNajveci(Cvor* kr, int k, int& brojac);
    Cvor* NadjiSljedbenika(Cvor *cvor);
public:
    class Iterator{
        Cvor* pok;
    public:
        Iterator(Cvor* cvor = nullptr):pok(cvor) {};
        Iterator(Iterator* it){
            pok = new Cvor(it->pok->element, it->pok->rod, it->pok->ld, it->pok->dd);
        }
        void operator =(Iterator *it){
            pok = new Cvor(it->pok->element, it->pok->rod, it->pok->ld, it->pok->dd);
        }
        Tip& operator*() { return pok->element; }
        Iterator IdiNaNajmanjiNaGrani();
        Iterator IdiNaNajveciNaGrani();
        Iterator operator++();
        Iterator operator++(int);
        friend class Stablo<Tip>;

    };
    class Reverse_Iterator{
        Cvor* pok;
    public:
        Reverse_Iterator(Cvor* cvor = nullptr):pok(cvor) {};
        Reverse_Iterator(Reverse_Iterator* it){
            pok = new Cvor(it->pok->element, it->pok->rod, it->pok->ld, it->pok->dd);
        }
        void operator =(Reverse_Iterator *it){
            pok = new Cvor(it->pok->element, it->pok->rod, it->pok->ld, it->pok->dd);
        }
        Tip& operator*() { return pok->element; }
        Reverse_Iterator IdiNaNajmanjiNaGrani();
        Reverse_Iterator IdiNaNajveciNaGrani();
        Reverse_Iterator operator++();
        Reverse_Iterator operator++(int);
        friend class Stablo<Tip>;

    };



    Stablo();
    Tip getNajmanjiElement(){return NadjiNajmanji(korijen)->element;};
    Cvor* Begin(){return NadjiNajmanji(korijen);};
    Cvor* End(){return NadjiNajveci(korijen);};
    Cvor* Korijen(){return korijen;};

    template <typename Tip1>
    friend bool provjeriPodstablo(Stablo<Tip1>& s1, Stablo<Tip1>& s2);


    Tip operator[](int k);

    pair<Cvor*,bool> Insert(Tip element);
    Cvor* Find(Tip element);
    void InOrderRek() { InOrderRek(korijen);}
    void InOrder();
    void Erase(Cvor* za_brisanje);
    int Erase(const Tip &element);
};
template <typename Tip>
bool provjeriPodstablo(Stablo<Tip>& s1, Stablo<Tip>& s2);

#include "stablo.cpp"

#endif // STABLO_H
