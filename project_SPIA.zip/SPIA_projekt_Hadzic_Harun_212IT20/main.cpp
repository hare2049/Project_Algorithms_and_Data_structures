#include <iostream>
#include "stablo.h"
using namespace std;

int main() {

    Stablo<int> s;
    s.Insert(20);
    s.Insert(30);
    s.Insert(25);
    s.Insert(35);
    s.Insert(10);
    s.Insert(5);
    s.Insert(15);
    s.Insert(32);
    s.Insert(12);
    s.Insert(17);
    s.Insert(18);

    cout << "Prvo stablo: ";
    s.InOrder();
    cout << endl;

    Stablo<int> s2;
    s2.Insert(15);
    s2.Insert(17);
    s2.Insert(18);
    s2.Insert(25);
    s2.Insert(32);

    cout << "Drugo stablo: ";
    s2.InOrder();
    cout << endl;

    cout << "Funkcija provjeri Stablo: ";
    cout << provjeriPodstablo(s2, s);
    cout << endl;
    cout << "Rad sa iteratorom: ";
    Stablo<int>::Iterator it2(s.Korijen());
    Stablo<int>::Reverse_Iterator it3(s.End());
    cout << *it2 << ' ';
    cout << *(++it2) << ' ';
    cout << *it2++ << ' ';
    cout << *it2 << endl;

    cout << "Rad sa Reverse Iteratorom: ";
    cout << *it3 << ' ';
    cout << *(++it3) << ' ';
    cout << *it3++ << ' ';
    cout << *it3 << endl;

    cout << "Indeksiranje: ";
    cout << s[9];

}

